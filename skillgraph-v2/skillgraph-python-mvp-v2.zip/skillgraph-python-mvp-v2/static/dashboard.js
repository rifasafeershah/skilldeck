const token = localStorage.getItem("skilldeck_token");
const user = JSON.parse(localStorage.getItem("skilldeck_user") || "null");

if (!token) location.href = "/login";

if (user) {
  document.getElementById("welcome").textContent = `Welcome, ${user.name}. Generate your SkillGraph below.`;
}

let activities = [
  { title: "Intro to SQL", type: "course", description: "SQL queries, Snowflake, database analytics" },
  { title: "Product Strategy for Product Managers", type: "course", description: "Product strategy, roadmapping, stakeholder management" },
  { title: "Data Visualization with Tableau", type: "course", description: "Tableau dashboards and data visualization" },
  { title: "Introduction to Snowflake", type: "certification", description: "Snowflake SQL database analytics" }
];

const items = document.getElementById("items");

function titleCase(text) {
  return text.replace(/\b\w/g, c => c.toUpperCase());
}

function renderItems() {
  items.innerHTML = "";
  activities.forEach((activity, index) => {
    const chip = document.createElement("span");
    chip.className = "chip";
    chip.innerHTML = `${activity.title} (${activity.type}) <button>×</button>`;
    chip.querySelector("button").onclick = () => {
      activities.splice(index, 1);
      renderItems();
    };
    items.appendChild(chip);
  });
}

renderItems();

document.getElementById("add").onclick = () => {
  const title = document.getElementById("title").value.trim();
  if (!title) return;

  activities.push({
    title,
    type: document.getElementById("type").value,
    description: document.getElementById("description").value.trim()
  });

  document.getElementById("title").value = "";
  document.getElementById("description").value = "";
  renderItems();
};

document.getElementById("logout").onclick = () => {
  localStorage.removeItem("skilldeck_token");
  localStorage.removeItem("skilldeck_user");
  location.href = "/";
};

document.getElementById("analyze").onclick = async () => {
  const res = await fetch("/api/analyze", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`
    },
    body: JSON.stringify({
      target_role: document.getElementById("role").value,
      activities
    })
  });

  const data = await res.json();
  if (!res.ok) {
    alert(data.detail || "Analysis failed");
    return;
  }
  renderResults(data);
};

function renderResults(data) {
  document.getElementById("empty").classList.add("hidden");
  document.getElementById("results").classList.remove("hidden");

  document.getElementById("targetFit").textContent = `${data.target_role_fit}%`;

  const top = Object.entries(data.role_matches)[0];
  document.getElementById("topMatch").textContent = top ? `${top[0]} (${top[1]}%)` : "-";

  const skillScores = document.getElementById("skillScores");
  skillScores.innerHTML = "";
  Object.entries(data.skill_scores).forEach(([skill, score]) => {
    const div = document.createElement("div");
    div.className = "score-row";
    div.innerHTML = `
      <div class="score-label"><strong>${titleCase(skill)}</strong><span>${score}</span></div>
      <div class="bar"><span style="width:${score}%"></span></div>
    `;
    skillScores.appendChild(div);
  });

  const roleMatches = document.getElementById("roleMatches");
  roleMatches.innerHTML = "";
  Object.entries(data.role_matches).forEach(([role, score]) => {
    roleMatches.innerHTML += `<tr><td>${role}</td><td>${score}%</td></tr>`;
  });

  const gaps = document.getElementById("gaps");
  gaps.innerHTML = "";
  if (data.skill_gaps.length === 0) {
    gaps.innerHTML = `<span class="chip success">No major gaps</span>`;
  } else {
    data.skill_gaps.forEach(gap => {
      gaps.innerHTML += `<span class="chip warning">${titleCase(gap)}</span>`;
    });
  }

  const recs = document.getElementById("recommendations");
  recs.innerHTML = "";
  data.recommendations.forEach(rec => {
    recs.innerHTML += `<li>${rec}</li>`;
  });
}
