const loginTab = document.getElementById("loginTab");
const registerTab = document.getElementById("registerTab");
const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");
const message = document.getElementById("message");

function showLogin() {
  loginTab.classList.add("active");
  registerTab.classList.remove("active");
  loginForm.classList.remove("hidden");
  registerForm.classList.add("hidden");
}

function showRegister() {
  registerTab.classList.add("active");
  loginTab.classList.remove("active");
  registerForm.classList.remove("hidden");
  loginForm.classList.add("hidden");
}

loginTab.onclick = showLogin;
registerTab.onclick = showRegister;

if (new URLSearchParams(window.location.search).get("mode") === "register") {
  showRegister();
}

async function postJSON(url, body) {
  const res = await fetch(url, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(body)
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.detail || "Request failed");
  return data;
}

loginForm.onsubmit = async (e) => {
  e.preventDefault();
  try {
    const data = await postJSON("/api/login", {
      email: document.getElementById("loginEmail").value,
      password: document.getElementById("loginPassword").value
    });
    localStorage.setItem("skilldeck_token", data.access_token);
    localStorage.setItem("skilldeck_user", JSON.stringify(data.user));
    location.href = "/dashboard";
  } catch (err) {
    message.textContent = err.message;
  }
};

registerForm.onsubmit = async (e) => {
  e.preventDefault();
  try {
    const data = await postJSON("/api/register", {
      name: document.getElementById("registerName").value,
      email: document.getElementById("registerEmail").value,
      password: document.getElementById("registerPassword").value
    });
    localStorage.setItem("skilldeck_token", data.access_token);
    localStorage.setItem("skilldeck_user", JSON.stringify(data.user));
    location.href = "/dashboard";
  } catch (err) {
    message.textContent = err.message;
  }
};
