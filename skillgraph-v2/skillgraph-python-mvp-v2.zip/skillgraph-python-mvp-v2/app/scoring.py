import json
from pathlib import Path
from typing import Dict, List

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"

POINTS = {
    "course": 25,
    "certification": 35,
    "project": 40
}

def load_json(filename: str):
    return json.loads((DATA_DIR / filename).read_text(encoding="utf-8"))

def extract_skills(title: str, description: str, keywords: Dict[str, List[str]]) -> List[str]:
    text = f"{title} {description}".lower()
    matches = []
    for skill, words in keywords.items():
        if any(word.lower() in text for word in words):
            matches.append(skill)
    return matches

def calculate_skill_scores(activities: List[dict]) -> Dict[str, int]:
    keywords = load_json("skill_keywords.json")
    scores: Dict[str, int] = {}

    for activity in activities:
        points = POINTS.get(activity.get("type", "course").lower(), 25)
        skills = extract_skills(
            activity.get("title", ""),
            activity.get("description", ""),
            keywords
        )
        for skill in skills:
            scores[skill] = min(100, scores.get(skill, 0) + points)

    return dict(sorted(scores.items(), key=lambda x: x[1], reverse=True))

def calculate_role_fit(skill_scores: Dict[str, int]) -> Dict[str, int]:
    roles = load_json("roles.json")
    results = {}

    for role, required_skills in roles.items():
        total = sum(skill_scores.get(skill, 0) for skill in required_skills)
        max_total = len(required_skills) * 100
        results[role] = round((total / max_total) * 100)

    return dict(sorted(results.items(), key=lambda x: x[1], reverse=True))

def recommendations(target_role: str, skill_scores: Dict[str, int]) -> dict:
    roles = load_json("roles.json")
    required = roles.get(target_role, [])
    gaps = [skill for skill in required if skill_scores.get(skill, 0) < 60]
    recs = [
        f"Improve {skill}: complete a focused course, build a portfolio project, or add a certification."
        for skill in gaps
    ]
    return {"gaps": gaps, "recommendations": recs}
