from pathlib import Path
from typing import Dict, List

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, EmailStr

from app.auth import create_token, decode_token, hash_password, verify_password
from app.scoring import calculate_role_fit, calculate_skill_scores, recommendations

BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "static"

app = FastAPI(title="SkillDeck MVP", version="2.0.0")
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

# In-memory MVP storage. Accounts reset when server restarts.
USERS: Dict[str, Dict] = {}

class RegisterRequest(BaseModel):
    name: str
    email: EmailStr
    password: str

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class LearningActivity(BaseModel):
    title: str
    type: str = "course"
    description: str = ""

class AnalyzeRequest(BaseModel):
    target_role: str
    activities: List[LearningActivity]

def get_current_user(authorization: str | None = Header(default=None)):
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Missing authorization token")
    token = authorization.split(" ", 1)[1]
    email = decode_token(token)
    if not email or email not in USERS:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    return USERS[email]

@app.get("/")
def home():
    return FileResponse(STATIC_DIR / "index.html")

@app.get("/login")
def login_page():
    return FileResponse(STATIC_DIR / "login.html")

@app.get("/dashboard")
def dashboard_page():
    return FileResponse(STATIC_DIR / "dashboard.html")

@app.post("/api/register")
def register(payload: RegisterRequest):
    email = payload.email.lower()
    if email in USERS:
        raise HTTPException(status_code=400, detail="Email already registered")
    USERS[email] = {
        "name": payload.name,
        "email": email,
        "password_hash": hash_password(payload.password),
        "role": "learner"
    }
    return {
        "access_token": create_token(email),
        "token_type": "bearer",
        "user": {"name": payload.name, "email": email}
    }

@app.post("/api/login")
def login(payload: LoginRequest):
    email = payload.email.lower()
    user = USERS.get(email)
    if not user or not verify_password(payload.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    return {
        "access_token": create_token(email),
        "token_type": "bearer",
        "user": {"name": user["name"], "email": email}
    }

@app.get("/api/me")
def me(user: Dict = Depends(get_current_user)):
    return {"name": user["name"], "email": user["email"], "role": user["role"]}

@app.post("/api/analyze")
def analyze(payload: AnalyzeRequest, user: Dict = Depends(get_current_user)):
    activities = [activity.model_dump() for activity in payload.activities]
    skill_scores = calculate_skill_scores(activities)
    role_matches = calculate_role_fit(skill_scores)
    gap_data = recommendations(payload.target_role, skill_scores)

    return {
        "target_role": payload.target_role,
        "skill_scores": skill_scores,
        "role_matches": role_matches,
        "target_role_fit": role_matches.get(payload.target_role, 0),
        "skill_gaps": gap_data["gaps"],
        "recommendations": gap_data["recommendations"]
    }

@app.get("/api/health")
def health():
    return {"status": "ok"}
