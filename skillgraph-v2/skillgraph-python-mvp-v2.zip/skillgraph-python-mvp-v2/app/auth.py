import base64
import hashlib
import hmac
import json
import time
from typing import Optional

SECRET_KEY = "skilldeck-dev-secret-change-me"
TOKEN_TTL_SECONDS = 60 * 60 * 8

def hash_password(password: str) -> str:
    return hashlib.sha256(("skilldeck-salt-" + password).encode()).hexdigest()

def verify_password(password: str, password_hash: str) -> bool:
    return hmac.compare_digest(hash_password(password), password_hash)

def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip("=")

def _unb64(data: str) -> bytes:
    return base64.urlsafe_b64decode(data + "=" * (-len(data) % 4))

def create_token(email: str) -> str:
    payload = {
        "sub": email,
        "exp": int(time.time()) + TOKEN_TTL_SECONDS
    }
    payload_b64 = _b64(json.dumps(payload).encode())
    signature = hmac.new(SECRET_KEY.encode(), payload_b64.encode(), hashlib.sha256).digest()
    return f"{payload_b64}.{_b64(signature)}"

def decode_token(token: str) -> Optional[str]:
    try:
        payload_b64, sig_b64 = token.split(".", 1)
        expected = hmac.new(SECRET_KEY.encode(), payload_b64.encode(), hashlib.sha256).digest()
        actual = _unb64(sig_b64)
        if not hmac.compare_digest(expected, actual):
            return None
        payload = json.loads(_unb64(payload_b64).decode())
        if payload.get("exp", 0) < int(time.time()):
            return None
        return payload.get("sub")
    except Exception:
        return None
