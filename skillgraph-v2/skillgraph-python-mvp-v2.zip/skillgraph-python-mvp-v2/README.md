# SkillDeck / SkillGraph Python MVP v2

This is an updated Python FastAPI MVP with:

- Landing page
- Login / sign-up page
- Protected dashboard
- Skill Score calculation
- Role Fit Score calculation
- Skill gap analysis
- Recommendations

## Run

```bash
python -m venv venv
source venv/Scripts/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

## Pages

```text
/             landing page
/login        login/sign up
/dashboard    protected SkillDeck dashboard
/docs         FastAPI docs
```

## Notes

This MVP uses in-memory auth storage. Accounts reset when the server restarts.
